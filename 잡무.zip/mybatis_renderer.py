import re
import xml.etree.ElementTree as ET

class OgnlValue:
    def __init__(self, val):
        self.val = val

    def equals(self, other):
        val_str = str(self.val) if self.val is not None else ""
        other_str = str(other.val) if isinstance(other, OgnlValue) else str(other)
        return val_str == other_str

    def equalsIgnoreCase(self, other):
        val_str = str(self.val) if self.val is not None else ""
        other_str = str(other.val) if isinstance(other, OgnlValue) else str(other)
        return val_str.lower() == other_str.lower()

    def size(self):
        if self.val is None:
            return 0
        if isinstance(self.val, (list, dict, set, tuple)):
            return len(self.val)
        return 0

    def length(self):
        if self.val is None:
            return 0
        return len(str(self.val))

    def isEmpty(self):
        if self.val is None:
            return True
        if isinstance(self.val, (list, dict, set, tuple, str)):
            return len(self.val) == 0
        return False

    def __eq__(self, other):
        other_val = other.val if isinstance(other, OgnlValue) else other
        if self.val is None and other_val is None:
            return True
        if self.val is None or other_val is None:
            return False
        return str(self.val) == str(other_val)

    def __ne__(self, other):
        return not self.__eq__(other)

    def __bool__(self):
        if self.val is None:
            return False
        if isinstance(self.val, str):
            return self.val.lower() not in ('', 'false', '0')
        return bool(self.val)

    def __getattr__(self, name):
        if isinstance(self.val, dict) and name in self.val:
            return OgnlValue(self.val[name])
        if name in ('equals', 'equalsIgnoreCase', 'size', 'length', 'isEmpty'):
            return getattr(self, name)
        return OgnlValue(None)

    def __getitem__(self, key):
        if isinstance(self.val, dict) and key in self.val:
            return OgnlValue(self.val[key])
        if isinstance(self.val, (list, tuple)) and isinstance(key, int):
            if 0 <= key < len(self.val):
                return OgnlValue(self.val[key])
        return OgnlValue(None)

    def __str__(self):
        return str(self.val) if self.val is not None else ""

    def __repr__(self):
        return f"OgnlValue({repr(self.val)})"


class OgnlContext(dict):
    def __init__(self, params):
        wrapped = {}
        for k, v in params.items():
            if not isinstance(v, OgnlValue):
                wrapped[k] = OgnlValue(v)
            else:
                wrapped[k] = v
        super().__init__(wrapped)

    def __getitem__(self, key):
        if key in self:
            return super().__getitem__(key)
        if key in ('True', 'False', 'None', 'isEmpty', 'isNotEmpty', 'toString', 'String'):
            raise KeyError(key)
        return OgnlValue(None)


def isEmpty(x):
    if x is None:
        return True
    if isinstance(x, OgnlValue):
        return x.isEmpty()
    if isinstance(x, (list, dict, set, tuple, str)):
        return len(x) == 0
    return False

def isNotEmpty(x):
    return not isEmpty(x)


def translate_ognl(expr):
    expr = re.sub(r'\&\&', ' and ', expr)
    expr = re.sub(r'\|\|', ' or ', expr)
    expr = re.sub(r'\band\b', ' and ', expr, flags=re.IGNORECASE)
    expr = re.sub(r'\bor\b', ' or ', expr, flags=re.IGNORECASE)
    expr = re.sub(r'\bnot\b', ' not ', expr, flags=re.IGNORECASE)
    expr = re.sub(r'\bnull\b', 'None', expr, flags=re.IGNORECASE)
    expr = re.sub(r'\btrue\b', 'True', expr, flags=re.IGNORECASE)
    expr = re.sub(r'\bfalse\b', 'False', expr, flags=re.IGNORECASE)
    expr = re.sub(r'!(?!=)', ' not ', expr)
    return expr


def evaluate_test(test_expr, params):
    translated = translate_ognl(test_expr)
    context = OgnlContext(params)
    globals_dict = {
        'isEmpty': isEmpty,
        'isNotEmpty': isNotEmpty,
        'None': None,
        'True': True,
        'False': False
    }
    try:
        result = eval(translated, globals_dict, context)
        return bool(result)
    except Exception:
        return False


def resolve_value_path(path, params):
    parts = path.strip().split('.')
    if not parts:
        return None
    
    first = parts[0]
    if first in params:
        current = params[first]
    else:
        return None
        
    for p in parts[1:]:
        if isinstance(current, OgnlValue):
            current = current.val
        if isinstance(current, dict) and p in current:
            current = current[p]
        elif hasattr(current, p):
            current = getattr(current, p)
        else:
            return None
            
    if isinstance(current, OgnlValue):
        return current.val
    return current


def format_sql_value(val, is_hash=True):
    if val is None:
        return "NULL" if is_hash else ""
        
    if isinstance(val, OgnlValue):
        val = val.val
        
    if isinstance(val, bool):
        return "1" if val else "0"
        
    if isinstance(val, (int, float)):
        return str(val)
        
    if isinstance(val, list):
        return ", ".join(format_sql_value(item, is_hash) for item in val)
        
    val_str = str(val)
    if is_hash:
        escaped = val_str.replace("'", "''")
        return f"'{escaped}'"
    else:
        return val_str


def replace_placeholders(text, params):
    if not text:
        return ""
        
    def hash_repl(match):
        path = match.group(1).split(',')[0].strip()
        val = resolve_value_path(path, params)
        return format_sql_value(val, is_hash=True)
        
    def dollar_repl(match):
        path = match.group(1).split(',')[0].strip()
        val = resolve_value_path(path, params)
        return format_sql_value(val, is_hash=False)
        
    def ibatis_repl(match):
        path = match.group(1).strip()
        val = resolve_value_path(path, params)
        return format_sql_value(val, is_hash=True)
        
    text = re.sub(r'#\{([^}]+)\}', hash_repl, text)
    text = re.sub(r'\$\{([^}]+)\}', dollar_repl, text)
    text = re.sub(r'#([a-zA-Z_][a-zA-Z0-9_.]*)#', ibatis_repl, text)
    return text



def render_children(parent_elem, params, sql_fragments):
    parts = []
    if parent_elem.text:
        parts.append(replace_placeholders(parent_elem.text, params))
        
    for child in parent_elem:
        child_text = render_element(child, params, sql_fragments)
        parts.append(child_text)
        if child.tail:
            parts.append(replace_placeholders(child.tail, params))
            
    return "".join(parts)


def render_element(elem, params, sql_fragments):
    tag = elem.tag
    
    if tag == 'if':
        test_expr = elem.attrib.get('test', '')
        if not evaluate_test(test_expr, params):
            return ""
        return render_children(elem, params, sql_fragments)
            
    elif tag == 'choose':
        done = False
        for child in elem:
            if child.tag == 'when':
                w_test = child.attrib.get('test', '')
                if evaluate_test(w_test, params):
                    return render_children(child, params, sql_fragments)
            elif child.tag == 'otherwise':
                pass
        # If no <when> matched, render <otherwise>
        otherwise_node = elem.find('otherwise')
        if otherwise_node is not None:
            return render_children(otherwise_node, params, sql_fragments)
        return ""

    elif tag == 'foreach':
        collection_name = elem.attrib.get('collection', '')
        item_name = elem.attrib.get('item', '')
        index_name = elem.attrib.get('index', '')
        open_str = elem.attrib.get('open', '')
        close_str = elem.attrib.get('close', '')
        separator = elem.attrib.get('separator', '')
        
        collection = resolve_value_path(collection_name, params)
        if not collection:
            collection = []
            
        if isinstance(collection, dict):
            items_list = list(collection.items())
        elif isinstance(collection, (list, tuple, set)):
            items_list = list(collection)
        else:
            items_list = [collection]
            
        rendered_items = []
        for i, item_val in enumerate(items_list):
            local_params = params.copy()
            if isinstance(collection, dict) and isinstance(item_val, tuple) and len(item_val) == 2:
                if index_name:
                    local_params[index_name] = item_val[0]
                if item_name:
                    local_params[item_name] = item_val[1]
            else:
                if item_name:
                    local_params[item_name] = item_val
                if index_name:
                    local_params[index_name] = i
                    
            item_text = render_children(elem, local_params, sql_fragments)
            rendered_items.append(item_text.strip())
            
        joined = f" {separator} ".join(rendered_items)
        return f"{open_str}{joined}{close_str}"

    elif tag == 'bind':
        bind_name = elem.attrib.get('name')
        bind_value_expr = elem.attrib.get('value')
        if bind_name and bind_value_expr:
            translated = translate_ognl(bind_value_expr)
            context = OgnlContext(params)
            globals_dict = {
                'isEmpty': isEmpty,
                'isNotEmpty': isNotEmpty,
                'None': None,
                'True': True,
                'False': False
            }
            try:
                val = eval(translated, globals_dict, context)
                if isinstance(val, OgnlValue):
                    val = val.val
                params[bind_name] = val
            except Exception:
                params[bind_name] = ""
        return ""

    elif tag == 'include':
        refid = elem.attrib.get('refid')
        if refid:
            target_id = refid.split('.')[-1]
            fragment = None
            for ns, frags in sql_fragments.items():
                if target_id in frags:
                    fragment = frags[target_id]
                    break
            if fragment is not None:
                return render_children(fragment, params, sql_fragments)
        return ""

    # General fallback for any other tags (e.g. where, trim, set, when, otherwise)
    rendered = render_children(elem, params, sql_fragments)
    
    if tag == 'where':
        cleaned = rendered.strip()
        cleaned = re.sub(r'^(AND|OR)\s+', '', cleaned, flags=re.IGNORECASE)
        if cleaned:
            return f" WHERE {cleaned} "
        return ""
        
    elif tag == 'set':
        cleaned = rendered.strip()
        cleaned = cleaned.rstrip(',')
        if cleaned:
            return f" SET {cleaned} "
        return ""
        
    elif tag == 'trim':
        prefix = elem.attrib.get('prefix', '')
        prefix_overrides = elem.attrib.get('prefixOverrides', '')
        suffix = elem.attrib.get('suffix', '')
        suffix_overrides = elem.attrib.get('suffixOverrides', '')
        
        cleaned = rendered.strip()
        
        if prefix_overrides:
            overrides = [o.strip() for o in prefix_overrides.split('|') if o.strip()]
            for o in overrides:
                pattern = r'^' + re.escape(o) + r'\s+'
                cleaned = re.sub(pattern, '', cleaned, flags=re.IGNORECASE)
                if cleaned.upper() == o.upper():
                    cleaned = ""
                    
        if suffix_overrides:
            overrides = [o.strip() for o in suffix_overrides.split('|') if o.strip()]
            for o in overrides:
                pattern = r'\s+' + re.escape(o) + r'$'
                cleaned = re.sub(pattern, '', cleaned, flags=re.IGNORECASE)
                if cleaned.endswith(o):
                    cleaned = cleaned[:-len(o)].strip()
                    
        if cleaned:
            return f" {prefix} {cleaned} {suffix} "
        return ""
        
    return rendered


def compile_query(elem, params, sql_fragments):
    """
    Given a query element (select/insert/update/delete) and the parameter values dictionary,
    compiles and renders the dynamic XML nodes into a final SQL query string.
    """
    params_copy = params.copy()
    raw_sql = render_children(elem, params_copy, sql_fragments)
    clean_sql = re.sub(r'\s+', ' ', raw_sql).strip()
    clean_sql = re.sub(r'/\*.*?\*/', '', clean_sql)
    return clean_sql

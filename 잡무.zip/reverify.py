import os
import re
import json
import xml.etree.ElementTree as ET
import psycopg2
import oracledb
import mybatis_renderer


# 1. 접속 정보 파싱
def parse_connection_info(filepath):
    print(f"[*] 접속 정보 파싱 중: {filepath}")
    with open(filepath, 'r', encoding='utf-8') as f:
        content = f.read()
    
    sections = content.strip().split('\n\n')
    db_configs = {}
    for section in sections:
        if not section.strip():
            continue
        lines = [line.strip() for line in section.strip().split('\n')]
        title = lines[0]
        config = {}
        for line in lines[1:]:
            if ':' in line:
                key, val = line.split(':', 1)
                config[key.strip().lower()] = val.strip()
        if 'oracle' in title.lower():
            db_configs['oracle'] = config
        elif 'postgresql' in title.lower():
            db_configs['postgresql'] = config
    return db_configs

# 2. MyBatis XML 로더
def load_mappers(base_dir):
    sql_fragments = {}
    query_elements = {}
    query_paths = {}
    
    for root_dir, dirs, files in os.walk(base_dir):
        for file in files:
            if file.endswith('.xml'):
                filepath = os.path.join(root_dir, file)
                rel_path = os.path.relpath(filepath, base_dir).replace('\\', '/')
                try:
                    tree = ET.parse(filepath)
                    root = tree.getroot()
                    if root.tag != 'mapper':
                        continue
                    namespace = root.attrib.get('namespace', '')
                    if not namespace:
                        continue
                    
                    if namespace not in sql_fragments:
                        sql_fragments[namespace] = {}
                    if namespace not in query_elements:
                        query_elements[namespace] = {}
                    if namespace not in query_paths:
                        query_paths[namespace] = {}
                    
                    # <sql> 태그 로드
                    for sql_tag in root.findall('.//sql'):
                        sql_id = sql_tag.attrib.get('id')
                        if sql_id:
                            sql_fragments[namespace][sql_id] = sql_tag
                            
                    # 쿼리 태그 로드 (<select>, <insert>, <update>, <delete>)
                    for tag in ['select', 'insert', 'update', 'delete']:
                        for elem in root.findall(f'.//{tag}'):
                            q_id = elem.attrib.get('id')
                            if q_id:
                                query_elements[namespace][q_id] = elem
                                query_paths[namespace][q_id] = rel_path
                except Exception as e:
                    print(f"[-] {filepath} 파싱 에러: {e}")
                    
    return sql_fragments, query_elements, query_paths

# 3. MyBatis include 리졸버 및 텍스트 추출 (정밀화 버전)
def extract_sql_text(elem, namespace, sql_fragments):
    text_parts = []
    
    # 1. 상호배타적인 <if> 태그 처리 필터
    tag = elem.tag
    if tag == 'if':
        test_attr = elem.attrib.get('test', '')
        test_lower = test_attr.lower()
        # null이거나 empty일 때 활성화되는 구문(대개 예외처리나 빈 값 조회 목적)은 스킵하고,
        # 값이 존재할 때(!= null, not empty)의 핵심 쿼리 구문 위주로 합칩니다.
        if '== null' in test_lower or 'isempty()' in test_lower or '== \'\'' in test_lower:
            return ""
            
    # 시작 텍스트 추가
    if elem.text:
        text_parts.append(elem.text)
        
    for child in elem:
        if child.tag == 'include':
            refid = child.attrib.get('refid')
            if refid:
                if '.' in refid:
                    parts = refid.split('.')
                    target_id = parts[-1]
                    target_ns = '.'.join(parts[:-1])
                else:
                    target_id = refid
                    target_ns = namespace
                
                fragment = sql_fragments.get(target_ns, {}).get(target_id)
                if fragment is not None:
                    text_parts.append(extract_sql_text(fragment, target_ns, sql_fragments))
                else:
                    print(f"[!] Warning: include refid '{refid}' 를 찾을 수 없습니다. (namespace: {namespace})")
        else:
            # 일반 자식 태그 처리
            child_text = extract_sql_text(child, namespace, sql_fragments)
            text_parts.append(child_text)
            
            # foreach 태그의 separator 속성 처리
            if child.tag == 'foreach':
                separator = child.attrib.get('separator')
                if separator and child_text.strip():
                    text_parts.append(f" {separator} ")
            
        # 자식 태그의 tail 텍스트
        if child.tail:
            text_parts.append(child.tail)
            
    return "".join(text_parts)

# 4. SQL 정제 (더미화 및 문법 예외 처리)
def clean_mybatis_sql(sql_text):
    # sidx, sord 등 정렬 변수 치환
    sql_text = re.sub(r'\$\{\s*sidx\s*\}', '1', sql_text, flags=re.IGNORECASE)
    sql_text = re.sub(r'\$\{\s*sord\s*\}', 'ASC', sql_text, flags=re.IGNORECASE)
    
    # AND ${customQuery} 또는 OR ${customQuery} -> AND 1=1 또는 OR 1=1
    sql_text = re.sub(r'(AND|OR)\s+\$\{\s*customQuery\s*\}', r'\1 1=1', sql_text, flags=re.IGNORECASE)
    
    # 단독 ${customQuery} 변수 치환
    sql_text = re.sub(r'\$\{\s*customQuery\s*\}', 'SELECT 1', sql_text, flags=re.IGNORECASE)
    
    # 기타 ${...} 일반 문자열 치환은 DUMMY_COL 또는 1로 변환
    sql_text = re.sub(r'\$\{[^}]+\}', '1', sql_text)
    
    # #{...} 파라미터 바인딩 변수 -> '1'로 치환 (문자형/숫자형 공통 지원용)
    sql_text = re.sub(r'#\{[^}]+\}', "'1'", sql_text)
    
    # iBatis #var# 문법 대응 -> '1'로 치환
    sql_text = re.sub(r'#[^#\s]+#', "'1'", sql_text)
    
    # 불필요한 줄바꿈 및 연속 공백 제거
    sql_text = re.sub(r'\s+', ' ', sql_text).strip()
    
    # 주석 제거 (선택 사항이나 EXPLAIN의 가독성을 위해)
    sql_text = re.sub(r'/\*.*?\*/', '', sql_text)
    
    return sql_text

# 5. DB별 구문 검증
def verify_oracle(conn, sql):
    sql_stripped = sql.strip().rstrip(';')
    if not sql_stripped:
        return False, "추출된 SQL이 비어있습니다."
    
    # 간혹 쿼리 뒤에 구분 기호나 쉼표가 남는 특수 상황 보정
    sql_stripped = sql_stripped.rstrip(',')
    
    explain_sql = f"EXPLAIN PLAN FOR {sql_stripped}"
    with conn.cursor() as cur:
        try:
            cur.execute(explain_sql)
            return True, "성공"
        except Exception as e:
            try:
                conn.rollback()
            except:
                pass
            return False, str(e)

def verify_postgresql(conn, sql):
    sql_stripped = sql.strip().rstrip(';')
    if not sql_stripped:
        return False, "추출된 SQL이 비어있습니다."
        
    sql_stripped = sql_stripped.rstrip(',')
    
    explain_sql = f"EXPLAIN {sql_stripped}"
    with conn.cursor() as cur:
        try:
            cur.execute(explain_sql)
            return True, "성공"
        except Exception as e:
            try:
                if not conn.autocommit:
                    conn.rollback()
            except:
                pass
            return False, str(e)

def classify_error(msg):
    if not msg:
        return "알 수 없음"
    if "XML에서 쿼리를 찾을 수 없습니다" in msg:
        return "XML 쿼리 미존재"
    if "MyBatis 컴파일 에러" in msg:
        return "컴파일 에러"
        
    msg_lower = msg.lower()
    
    # 1. Missing Table or Column (Schema issue)
    schema_keywords = [
        "ora-00942", # table or view does not exist
        "ora-00904", # invalid identifier (column not found)
        "릴레이션(relation)이 없습니다",
        "relation",
        "칼럼(column)이 없습니다",
        "column",
        "does not exist"
    ]
    if any(k in msg_lower for k in schema_keywords):
        return "테이블/컬럼 미존재"
        
    # 2. Type / Function Mismatch
    type_keywords = [
        "ora-00932", # inconsistent datatypes
        "ora-01722", # invalid number
        "ora-01840", # input value length error
        "ora-01861", # literal does not match format string
        "함수가 없음",
        "자료형",
        "연산자 없음",
        "operator does not exist",
        "function does not exist",
        "coalesce 자료형",
        "자료형은 서로 매치되지 않습니다"
    ]
    if any(k in msg_lower for k in type_keywords):
        return "타입/함수 오류"
        
    # 3. Syntax Error
    syntax_keywords = [
        "ora-00900", # invalid SQL statement
        "ora-00903", # invalid table name
        "ora-00905", # missing keyword
        "ora-00906", # missing left parenthesis
        "ora-00907", # missing right parenthesis
        "ora-00911", # invalid character
        "ora-00918", # column ambiguously defined
        "ora-00920", # invalid relational operator
        "ora-00923", # FROM keyword not found where expected
        "ora-00933", # SQL command not properly ended
        "ora-00936", # missing expression
        "ora-02287", # sequence number not allowed here
        "구문 오류",
        "syntax error"
    ]
    if any(k in msg_lower for k in syntax_keywords):
        return "구문 에러"
        
    return "기타 에러"

def write_html_report(report_path, results):
    results_json = json.dumps(results, ensure_ascii=False)
    
    html_content = f"""<!DOCTYPE html>
<html lang="ko">
<head>
    <meta charset="UTF-8">
    <title>Query 재검증 결과 리포트</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <style>
        :root {{
            --bg-color: #0f172a;
            --card-bg: #1e293b;
            --border-color: #334155;
            --text-main: #f1f5f9;
            --text-muted: #94a3b8;
            --primary: #3b82f6;
            --success: #10b981;
            --success-bg: rgba(16, 185, 129, 0.15);
            --error: #ef4444;
            --error-bg: rgba(239, 68, 68, 0.15);
            --warning: #f59e0b;
            --warning-bg: rgba(245, 158, 11, 0.15);
            --decision-ok: #059669;
            --decision-pg: #dc2626;
            --decision-ora: #d97706;
            --decision-both: #4b5563;
        }}
        * {{
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }}
        body {{
            font-family: 'Inter', -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
            background-color: var(--bg-color);
            color: var(--text-main);
            padding: 2rem;
            line-height: 1.5;
        }}
        .container {{
            max-width: 1400px;
            margin: 0 auto;
        }}
        header {{
            margin-bottom: 2rem;
        }}
        header h1 {{
            font-size: 2.25rem;
            font-weight: 700;
            margin-bottom: 0.5rem;
            background: linear-gradient(to right, #60a5fa, #34d399);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }}
        header p {{
            color: var(--text-muted);
            font-size: 1.1rem;
        }}
        .metrics-grid {{
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
            gap: 1.5rem;
            margin-bottom: 2rem;
        }}
        .metric-card {{
            background-color: var(--card-bg);
            border: 1px solid var(--border-color);
            border-radius: 0.75rem;
            padding: 1.5rem;
            display: flex;
            flex-direction: column;
        }}
        .metric-title {{
            font-size: 0.875rem;
            color: var(--text-muted);
            margin-bottom: 0.5rem;
            font-weight: 500;
        }}
        .metric-value {{
            font-size: 1.75rem;
            font-weight: 700;
        }}
        .metric-value.success {{ color: var(--success); }}
        .metric-value.error {{ color: var(--error); }}
        .metric-value.warning {{ color: var(--warning); }}
        
        .filters-panel {{
            background-color: var(--card-bg);
            border: 1px solid var(--border-color);
            border-radius: 0.75rem;
            padding: 1.5rem;
            margin-bottom: 2rem;
            display: flex;
            flex-wrap: wrap;
            gap: 1.5rem;
            align-items: center;
        }}
        .filter-group {{
            display: flex;
            flex-direction: column;
            gap: 0.5rem;
            flex: 1;
            min-width: 200px;
        }}
        .filter-group.search {{
            flex: 2;
        }}
        .filter-group label {{
            font-size: 0.875rem;
            font-weight: 600;
            color: var(--text-muted);
        }}
        .filter-group input, .filter-group select {{
            background-color: var(--bg-color);
            border: 1px solid var(--border-color);
            color: var(--text-main);
            padding: 0.625rem 1rem;
            border-radius: 0.5rem;
            outline: none;
            font-family: inherit;
            font-size: 0.95rem;
            transition: border-color 0.2s;
        }}
        .filter-group input:focus, .filter-group select:focus {{
            border-color: var(--primary);
        }}
        
        .table-container {{
            background-color: var(--card-bg);
            border: 1px solid var(--border-color);
            border-radius: 0.75rem;
            overflow: hidden;
        }}
        table {{
            width: 100%;
            border-collapse: collapse;
            text-align: left;
        }}
        th, td {{
            padding: 1rem 1.5rem;
            border-bottom: 1px solid var(--border-color);
        }}
        th {{
            background-color: rgba(0, 0, 0, 0.2);
            color: var(--text-muted);
            font-weight: 600;
            font-size: 0.875rem;
            text-transform: uppercase;
            letter-spacing: 0.05em;
        }}
        tr.main-row {{
            cursor: pointer;
            transition: background-color 0.15s;
        }}
        tr.main-row:hover {{
            background-color: rgba(255, 255, 255, 0.03);
        }}
        .badge {{
            display: inline-flex;
            align-items: center;
            padding: 0.25rem 0.75rem;
            border-radius: 9999px;
            font-size: 0.85rem;
            font-weight: 500;
        }}
        .badge.success {{
            background-color: var(--success-bg);
            color: var(--success);
        }}
        .badge.error {{
            background-color: var(--error-bg);
            color: var(--error);
        }}
        .badge.decision-ok {{ background-color: rgba(16, 185, 129, 0.2); color: #34d399; }}
        .badge.decision-pg {{ background-color: rgba(239, 68, 68, 0.2); color: #f87171; }}
        .badge.decision-ora {{ background-color: rgba(245, 158, 11, 0.2); color: #fbbf24; }}
        .badge.decision-both {{ background-color: rgba(148, 163, 184, 0.2); color: #cbd5e1; }}
        
        .detail-row {{
            display: none;
            background-color: rgba(0, 0, 0, 0.15);
        }}
        .detail-row.expanded {{
            display: table-row;
        }}
        .detail-content {{
            padding: 1.5rem;
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 1.5rem;
        }}
        .db-detail-block {{
            background-color: var(--bg-color);
            border: 1px solid var(--border-color);
            border-radius: 0.5rem;
            padding: 1rem;
        }}
        .db-detail-block h4 {{
            margin-bottom: 0.5rem;
            font-size: 1rem;
            font-weight: 600;
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }}
        .db-detail-block h4.ok {{ color: var(--success); }}
        .db-detail-block h4.err {{ color: var(--error); }}
        
        .db-detail-block pre {{
            background-color: #000;
            color: #10b981;
            padding: 0.75rem;
            border-radius: 0.25rem;
            font-family: 'Courier New', Courier, monospace;
            font-size: 0.85rem;
            overflow-x: auto;
            margin-top: 0.5rem;
            white-space: pre-wrap;
            word-break: break-all;
        }}
        .db-detail-block .err-msg {{
            color: #f87171;
            font-size: 0.9rem;
            margin-bottom: 0.5rem;
            background-color: rgba(239, 68, 68, 0.1);
            padding: 0.5rem;
            border-radius: 0.25rem;
            border-left: 3px solid var(--error);
        }}
        
        /* Pagination */
        .pagination {{
            margin-top: 1.5rem;
            display: flex;
            justify-content: space-between;
            align-items: center;
            color: var(--text-muted);
            font-size: 0.9rem;
        }}
        .pagination-buttons {{
            display: flex;
            gap: 0.5rem;
        }}
        .pagination-btn {{
            background-color: var(--card-bg);
            border: 1px solid var(--border-color);
            color: var(--text-main);
            padding: 0.5rem 1rem;
            border-radius: 0.375rem;
            cursor: pointer;
            font-family: inherit;
            transition: all 0.2s;
        }}
        .pagination-btn:hover:not(:disabled) {{
            border-color: var(--primary);
            background-color: rgba(59, 130, 246, 0.1);
        }}
        .pagination-btn:disabled {{
            opacity: 0.5;
            cursor: not-allowed;
        }}
    </style>
</head>
<body>
    <div class="container">
        <header>
            <h1>Query 재검증 결과 대시보드</h1>
            <p>전체 XML 매퍼의 MyBatis 쿼리 컴파일 및 DB 구문 검증(EXPLAIN) 모니터링</p>
        </header>
        
        <div class="metrics-grid">
            <div class="metric-card">
                <div class="metric-title">총 검증 쿼리</div>
                <div class="metric-value" id="metric-total">0</div>
            </div>
            <div class="metric-card">
                <div class="metric-title">양측 모두 정상 (🟢)</div>
                <div class="metric-value success" id="metric-both">0</div>
            </div>
            <div class="metric-card">
                <div class="metric-title">오라클만 정상 (🔴 PG 수정 필요)</div>
                <div class="metric-value warning" id="metric-ora">0</div>
            </div>
            <div class="metric-card">
                <div class="metric-title">포스트그레만 정상 (🟡 오라클 에러)</div>
                <div class="metric-value warning" id="metric-pg">0</div>
            </div>
            <div class="metric-card">
                <div class="metric-title">양측 모두 에러 (⚫)</div>
                <div class="metric-value error" id="metric-none">0</div>
            </div>
        </div>
        
        <div class="filters-panel">
            <div class="filter-group search">
                <label for="filter-search">쿼리 Key 검색</label>
                <input type="text" id="filter-search" placeholder="파일명 또는 쿼리 ID 검색...">
            </div>
            <div class="filter-group">
                <label for="filter-oracle">Oracle 검증</label>
                <select id="filter-oracle">
                    <option value="ALL">전체</option>
                    <option value="SUCCESS">✅ 성공</option>
                    <option value="테이블/컬럼 미존재">❌ 테이블/컬럼 미존재</option>
                    <option value="구문 에러">❌ 구문 에러</option>
                    <option value="타입/함수 오류">❌ 타입/함수 오류</option>
                    <option value="컴파일 에러">❌ 컴파일 에러</option>
                    <option value="기타 에러">❌ 기타 에러</option>
                </select>
            </div>
            <div class="filter-group">
                <label for="filter-postgres">PostgreSQL 검증</label>
                <select id="filter-postgres">
                    <option value="ALL">전체</option>
                    <option value="SUCCESS">✅ 성공</option>
                    <option value="테이블/컬럼 미존재">❌ 테이블/컬럼 미존재</option>
                    <option value="구문 에러">❌ 구문 에러</option>
                    <option value="타입/함수 오류">❌ 타입/함수 오류</option>
                    <option value="컴파일 에러">❌ 컴파일 에러</option>
                    <option value="기타 에러">❌ 기타 에러</option>
                </select>
            </div>
            <div class="filter-group">
                <label for="filter-decision">판정 결과</label>
                <select id="filter-decision">
                    <option value="ALL">전체</option>
                    <option value="정상">🟢 정상</option>
                    <option value="PG">🔴 PG 수정 필요</option>
                    <option value="오라클">🟡 오라클 에러</option>
                    <option value="양측">⚫ 양측 에러</option>
                </select>
            </div>
        </div>
        
        <div class="table-container">
            <table>
                <thead>
                    <tr>
                        <th style="width: 70px;">번호</th>
                        <th>쿼리 Key</th>
                        <th style="width: 250px;">Oracle 검증</th>
                        <th style="width: 250px;">PostgreSQL 검증</th>
                        <th style="width: 180px;">판정</th>
                    </tr>
                </thead>
                <tbody id="table-body">
                    <!-- Dynamic Rows -->
                </tbody>
            </table>
        </div>
        
        <div class="pagination">
            <div id="pagination-info">showing 0-0 of 0</div>
            <div class="pagination-buttons">
                <button class="pagination-btn" id="btn-prev" disabled>이전</button>
                <button class="pagination-btn" id="btn-next" disabled>다음</button>
            </div>
        </div>
    </div>
    
    <script>
        const rawData = {results_json};
        
        let filteredData = [...rawData];
        let currentPage = 1;
        const rowsPerPage = 50;
        
        // Setup stats metrics
        let total = rawData.length;
        let both = 0, oraOnly = 0, pgOnly = 0, none = 0;
        rawData.forEach(r => {{
            const o = r.oracle.ok;
            const p = r.postgresql.ok;
            if (o && p) both++;
            else if (o && !p) oraOnly++;
            else if (!o && p) pgOnly++;
            else none++;
        }});
        
        document.getElementById('metric-total').innerText = total;
        document.getElementById('metric-both').innerText = both;
        document.getElementById('metric-ora').innerText = oraOnly;
        document.getElementById('metric-pg').innerText = pgOnly;
        document.getElementById('metric-none').innerText = none;
        
        // Elements
        const searchInput = document.getElementById('filter-search');
        const oracleSelect = document.getElementById('filter-oracle');
        const postgresSelect = document.getElementById('filter-postgres');
        const decisionSelect = document.getElementById('filter-decision');
        const tableBody = document.getElementById('table-body');
        const prevBtn = document.getElementById('btn-prev');
        const nextBtn = document.getElementById('btn-next');
        const infoDiv = document.getElementById('pagination-info');
        
        function classifyError(ok, msg) {{
            if (ok) return "SUCCESS";
            if (!msg) return "기타 에러";
            if (msg.includes("XML에서 쿼리를 찾을 수 없습니다")) return "XML 쿼리 미존재";
            if (msg.includes("MyBatis 컴파일 에러")) return "컴파일 에러";
            
            const msgLower = msg.toLowerCase();
            const schemaKeywords = ["ora-00942", "ora-00904", "릴레이션", "relation", "칼럼", "column", "does not exist"];
            if (schemaKeywords.some(k => msgLower.includes(k))) return "테이블/컬럼 미존재";
            
            const typeKeywords = ["ora-00932", "ora-01722", "ora-01840", "ora-01861", "함수가 없음", "자료형", "연산자 없음", "operator does not exist", "function does not exist", "coalesce"];
            if (typeKeywords.some(k => msgLower.includes(k))) return "타입/함수 오류";
            
            const syntaxKeywords = ["ora-00900", "ora-00903", "ora-00905", "ora-00906", "ora-00907", "ora-00911", "ora-00918", "ora-00920", "ora-00923", "ora-00933", "ora-00936", "ora-02287", "구문 오류", "syntax error"];
            if (syntaxKeywords.some(k => msgLower.includes(k))) return "구문 에러";
            
            return "기타 에러";
        }}
        
        function applyFilters() {{
            const search = searchInput.value.toLowerCase();
            const oraFilter = oracleSelect.value;
            const pgFilter = postgresSelect.value;
            const decFilter = decisionSelect.value;
            
            filteredData = rawData.filter(r => {{
                // Search term
                if (search && !r.key.toLowerCase().includes(search)) return false;
                
                // Oracle filter
                const oClass = classifyError(r.oracle.ok, r.oracle.msg);
                if (oraFilter !== 'ALL') {{
                    if (oraFilter === 'SUCCESS' && oClass !== 'SUCCESS') return false;
                    if (oraFilter !== 'SUCCESS' && oClass !== oraFilter) return false;
                }}
                
                // Postgres filter
                const pClass = classifyError(r.postgresql.ok, r.postgresql.msg);
                if (postgresSelect.value !== 'ALL') {{
                    if (pgFilter === 'SUCCESS' && pClass !== 'SUCCESS') return false;
                    if (pgFilter !== 'SUCCESS' && pClass !== pgFilter) return false;
                }}
                
                // Decision filter
                if (decFilter !== 'ALL') {{
                    const o = r.oracle.ok;
                    const p = r.postgresql.ok;
                    if (decFilter === '정상' && !(o && p)) return false;
                    if (decFilter === 'PG' && !(o && !p)) return false;
                    if (decFilter === '오라클' && !(!o && p)) return false;
                    if (decFilter === '양측' && !(!o && !p)) return false;
                }}
                
                return true;
            }});
            
            currentPage = 1;
            renderTable();
        }}
        
        function renderTable() {{
            tableBody.innerHTML = '';
            
            if (filteredData.length === 0) {{
                tableBody.innerHTML = `<tr><td colspan="5" style="text-align: center; color: var(--text-muted); padding: 3rem;">검색 조건에 맞는 결과가 없습니다.</td></tr>`;
                infoDiv.innerText = 'showing 0-0 of 0';
                prevBtn.disabled = true;
                nextBtn.disabled = true;
                return;
            }}
            
            const startIdx = (currentPage - 1) * rowsPerPage;
            const endIdx = Math.min(startIdx + rowsPerPage, filteredData.length);
            
            const pageData = filteredData.slice(startIdx, endIdx);
            
            pageData.forEach((r, index) => {{
                const globalIdx = startIdx + index + 1;
                
                // Badges
                const oClass = classifyError(r.oracle.ok, r.oracle.msg);
                const pClass = classifyError(r.postgresql.ok, r.postgresql.msg);
                
                const oBadge = r.oracle.ok 
                    ? `<span class="badge success">✅ 성공</span>` 
                    : `<span class="badge error">❌ 실패 (${{oClass}})</span>`;
                    
                const pBadge = r.postgresql.ok 
                    ? `<span class="badge success">✅ 성공</span>` 
                    : `<span class="badge error">❌ 실패 (${{pClass}})</span>`;
                    
                let decBadge = '';
                if (r.oracle.ok && r.postgresql.ok) decBadge = `<span class="badge decision-ok">🟢 정상</span>`;
                else if (r.oracle.ok && !r.postgresql.ok) decBadge = `<span class="badge decision-pg">🔴 PG 수정 필요</span>`;
                else if (!r.oracle.ok && r.postgresql.ok) decBadge = `<span class="badge decision-ora">🟡 오라클 에러</span>`;
                else decBadge = `<span class="badge decision-both">⚫ 양측 에러</span>`;
                
                const mainRow = document.createElement('tr');
                mainRow.className = 'main-row';
                mainRow.innerHTML = `
                    <td>${{globalIdx}}</td>
                    <td style="font-weight: 500;">${{r.key}}</td>
                    <td>${{oBadge}}</td>
                    <td>${{pBadge}}</td>
                    <td>${{decBadge}}</td>
                `;
                
                const detailRow = document.createElement('tr');
                detailRow.className = 'detail-row';
                
                // Oracle detail block
                const oBlock = r.oracle.ok 
                    ? `<div class="db-detail-block"><h4 class="ok">🟢 Oracle 성공</h4><pre>-- EXPLAIN 성공</pre></div>`
                    : `<div class="db-detail-block">
                           <h4 class="err">🔴 Oracle 에러 (${{oClass}})</h4>
                           <div class="err-msg">${{escapeHtml(r.oracle.msg)}}</div>
                           <strong>검증 SQL:</strong>
                           <pre>${{escapeHtml(r.oracle.sql || 'SQL 없음')}}</pre>
                       </div>`;
                       
                // PostgreSQL detail block
                const pBlock = r.postgresql.ok 
                    ? `<div class="db-detail-block"><h4 class="ok">🟢 PostgreSQL 성공</h4><pre>-- EXPLAIN 성공</pre></div>`
                    : `<div class="db-detail-block">
                           <h4 class="err">🔴 PostgreSQL 에러 (${{pClass}})</h4>
                           <div class="err-msg">${{escapeHtml(r.postgresql.msg)}}</div>
                           <strong>검증 SQL:</strong>
                           <pre>${{escapeHtml(r.postgresql.sql || 'SQL 없음')}}</pre>
                       </div>`;
                       
                detailRow.innerHTML = `
                    <td colspan="5">
                        <div class="detail-content">
                            ${{oBlock}}
                            ${{pBlock}}
                        </div>
                    </td>
                `;
                
                mainRow.addEventListener('click', () => {{
                    detailRow.classList.toggle('expanded');
                }});
                
                tableBody.appendChild(mainRow);
                tableBody.appendChild(detailRow);
            }});
            
            infoDiv.innerText = `showing ${{startIdx + 1}}-${{endIdx}} of ${{filteredData.length}}`;
            prevBtn.disabled = currentPage === 1;
            nextBtn.disabled = endIdx >= filteredData.length;
        }}
        
        function escapeHtml(str) {{
            if (!str) return '';
            return str
                .replace(/&/g, "&amp;")
                .replace(/</g, "&lt;")
                .replace(/>/g, "&gt;")
                .replace(/"/g, "&quot;")
                .replace(/'/g, "&#039;");
        }}
        
        // Listeners
        searchInput.addEventListener('input', applyFilters);
        oracleSelect.addEventListener('change', applyFilters);
        postgresSelect.addEventListener('change', applyFilters);
        decisionSelect.addEventListener('change', applyFilters);
        
        prevBtn.addEventListener('click', () => {{
            if (currentPage > 1) {{
                currentPage--;
                renderTable();
            }}
        }});
        
        nextBtn.addEventListener('click', () => {{
            if ((currentPage * rowsPerPage) < filteredData.length) {{
                currentPage++;
                renderTable();
            }}
        }});
        
        // Initial render
        renderTable();
    </script>
</body>
</html>"""
    
    with open(report_path, 'w', encoding='utf-8') as f:
        f.write(html_content)
    print(f"[+] 대화형 HTML 리포트 생성 완료: {report_path}")

# 메인 실행 흐름
def main():
    workspace_dir = r"d:\유틸\잡무"
    conn_info_file = os.path.join(workspace_dir, "접속정보.md")
    error_list_file = os.path.join(workspace_dir, "Query List-error.json")
    
    db_configs = parse_connection_info(conn_info_file)
    
    # DB 연결 개시
    oracle_conn = None
    pg_conn = None
    
    print("[*] Oracle 데이터베이스 연결 중...")
    try:
        ora_conf = db_configs['oracle']
        host_ip, port = ora_conf['host'].split(':')
        dsn = oracledb.makedsn(host_ip, port, sid=ora_conf['sid'])
        oracle_conn = oracledb.connect(
            user=ora_conf['user'],
            password=ora_conf['password'],
            dsn=dsn
        )
        with oracle_conn.cursor() as cur:
            cur.execute(f"ALTER SESSION SET CURRENT_SCHEMA = {ora_conf['schema']}")
        print("[+] Oracle 연결 완료 (Schema: {})".format(ora_conf['schema']))
    except Exception as e:
        print(f"[-] Oracle 연결 실패: {e}")
        
    print("[*] PostgreSQL 데이터베이스 연결 중...")
    try:
        pg_conf = db_configs['postgresql']
        host_ip = pg_conf['host'].split(':')[0]
        port = pg_conf['host'].split(':')[1] if ':' in pg_conf['host'] else '5432'
        pg_conn = psycopg2.connect(
            host=host_ip,
            port=port,
            database=pg_conf['database'],
            user=pg_conf['user'],
            password=pg_conf['password'],
            options=f"-c search_path={pg_conf['schema']},public"
        )
        pg_conn.autocommit = True
        print("[+] PostgreSQL 연결 완료 (Schema: {})".format(pg_conf['schema']))
    except Exception as e:
        print(f"[-] PostgreSQL 연결 실패: {e}")

    if not oracle_conn or not pg_conn:
        print("[!] DB 연결 오류가 발생하여 검증을 진행할 수 없습니다.")
        if oracle_conn: oracle_conn.close()
        if pg_conn: pg_conn.close()
        return

    # 변수 정의 파일 로드
    query_params = {}
    vars_file = os.path.join(workspace_dir, "query_variables.json")
    if os.path.exists(vars_file):
        print(f"[*] 변수 정의 파일 로딩 중: {vars_file}")
        try:
            with open(vars_file, 'r', encoding='utf-8') as f:
                query_params = json.load(f)
            print(f"[+] {len(query_params)} 개의 변수 로딩 성공")
        except Exception as e:
            print(f"[-] 변수 파일 파싱 실패: {e}")
    else:
        print("[!] 변수 정의 파일(query_variables.json)을 찾을 수 없습니다. 빈 딕셔너리로 진행합니다.")

    # XML 로드
    print("[*] XML 매퍼 파일 로딩 및 파싱...")
    ora_fragments, ora_queries, ora_paths = load_mappers(os.path.join(workspace_dir, "oracle"))
    pg_fragments, pg_queries, pg_paths = load_mappers(os.path.join(workspace_dir, "postgresql"))

    # Collect all unique query keys from both Oracle and PostgreSQL
    all_keys = set()
    key_details = {}
    
    for ns, q_paths in ora_paths.items():
        for q_id, rel_path in q_paths.items():
            key = f"{rel_path}::{q_id}"
            all_keys.add(key)
            key_details[key] = {
                'ns': ns,
                'q_id': q_id,
                'rel_path': rel_path
            }
            
    for ns, q_paths in pg_paths.items():
        for q_id, rel_path in q_paths.items():
            key = f"{rel_path}::{q_id}"
            all_keys.add(key)
            if key not in key_details:
                key_details[key] = {
                    'ns': ns,
                    'q_id': q_id,
                    'rel_path': rel_path
                }
                
    sorted_keys = sorted(list(all_keys))
    print(f"[*] 총 검증 대상 쿼리 항목: {len(sorted_keys)} 개")

    results = []
    
    for idx, key in enumerate(sorted_keys):
        details = key_details[key]
        path = details['rel_path']
        q_id = details['q_id']
        ns = details['ns']
        
        print(f"[{idx+1}/{len(sorted_keys)}] 검증 중: {key}")
        
        ora_sql_clean = None
        pg_sql_clean = None
        ora_ok, ora_msg = False, "XML에서 쿼리를 찾을 수 없습니다."
        pg_ok, pg_msg = False, "XML에서 쿼리를 찾을 수 없습니다."
        
        # 1. Oracle 쿼리 추출 및 컴파일
        ora_elem = ora_queries.get(ns, {}).get(q_id)
        if ora_elem is not None:
            try:
                ora_sql_clean = mybatis_renderer.compile_query(ora_elem, query_params, ora_fragments)
                ora_ok, ora_msg = verify_oracle(oracle_conn, ora_sql_clean)
            except Exception as e:
                ora_sql_clean = None
                ora_ok, ora_msg = False, f"MyBatis 컴파일 에러: {e}"
            
        # 2. PostgreSQL 쿼리 추출 및 컴파일
        pg_elem = pg_queries.get(ns, {}).get(q_id)
        if pg_elem is not None:
            try:
                pg_sql_clean = mybatis_renderer.compile_query(pg_elem, query_params, pg_fragments)
                pg_ok, pg_msg = verify_postgresql(pg_conn, pg_sql_clean)
            except Exception as e:
                pg_sql_clean = None
                pg_ok, pg_msg = False, f"MyBatis 컴파일 에러: {e}"

        results.append({
            'key': key,
            'path': path,
            'id': q_id,
            'prev_error': 'N/A',
            'oracle': {
                'ok': ora_ok,
                'msg': ora_msg,
                'sql': ora_sql_clean
            },
            'postgresql': {
                'ok': pg_ok,
                'msg': pg_msg,
                'sql': pg_sql_clean
            }
        })

    # DB 연결 정리
    oracle_conn.close()
    pg_conn.close()

    # 리포트 파일 작성
    report_path = os.path.join(workspace_dir, "reverify_report.md")
    print(f"[*] 리포트 작성 중: {report_path}")
    
    with open(report_path, 'w', encoding='utf-8') as f:
        f.write("# Query 재검증 결과 리포트\n\n")
        f.write("본 리포트는 실제 Oracle 및 PostgreSQL DB에 접속하여 각 XML 쿼리의 문법 에러(Syntax Error)를 직접 재검증한 결과입니다.\n\n")
        f.write("> 💡 **대화형 필터 및 검색이 필요하신가요?**\n")
        f.write("> 본 리포트는 검증 대상 항목이 매우 많으므로, 실시간 검색, DB 검증 결과별 필터링, 그리고 확장형 상세 에러 로그 조회가 가능한 **[대화형 HTML 리포트 (reverify_report.html)](./reverify_report.html)** 파일을 브라우저로 열어서 확인하시는 것을 강력히 권장합니다.\n\n")
        
        # 요약 테이블
        success_both = 0
        success_ora_only = 0
        success_pg_only = 0
        failed_both = 0
        for r in results:
            o_ok = r['oracle']['ok']
            p_ok = r['postgresql']['ok']
            if o_ok and p_ok: success_both += 1
            elif o_ok and not p_ok: success_ora_only += 1
            elif not o_ok and p_ok: success_pg_only += 1
            else: failed_both += 1
            
        f.write("## 1. 재검증 결과 요약\n\n")
        f.write(f"- **총 검증 대상 쿼리**: {len(results)} 개\n")
        f.write(f"- **양쪽 DB 모두 구문 성공**: {success_both} 개 (실제 구문 정상)\n")
        f.write(f"- **Oracle만 성공 (PostgreSQL 에러)**: {success_ora_only} 개 (포스트그레 수정 필요)\n")
        f.write(f"- **PostgreSQL만 성공 (Oracle 에러)**: {success_pg_only} 개 (오라클 쿼리에 결함이 있거나 더미 데이터 문제)\n")
        f.write(f"- **양쪽 모두 에러**: {failed_both} 개\n\n")
        
        # 오류 유형별 통계 집계 및 작성
        ora_err_cats = {}
        pg_err_cats = {}
        for r in results:
            if not r['oracle']['ok']:
                cat = classify_error(r['oracle']['msg'])
                ora_err_cats[cat] = ora_err_cats.get(cat, 0) + 1
            if not r['postgresql']['ok']:
                cat = classify_error(r['postgresql']['msg'])
                pg_err_cats[cat] = pg_err_cats.get(cat, 0) + 1
                
        f.write("### [오류 유형별 통계]\n\n")
        f.write("#### Oracle 오류 유형 통계\n")
        if ora_err_cats:
            for cat, cnt in sorted(ora_err_cats.items(), key=lambda x: x[1], reverse=True):
                f.write(f"- **{cat}**: {cnt} 개\n")
        else:
            f.write("- 오류 없음\n")
            
        f.write("\n#### PostgreSQL 오류 유형 통계\n")
        if pg_err_cats:
            for cat, cnt in sorted(pg_err_cats.items(), key=lambda x: x[1], reverse=True):
                f.write(f"- **{cat}**: {cnt} 개\n")
        else:
            f.write("- 오류 없음\n")
        f.write("\n")
        
        f.write("| 번호 | 쿼리 Key | Oracle 검증 | PostgreSQL 검증 | 판정 | \n")
        f.write("| --- | --- | --- | --- | --- |\n")
        for i, r in enumerate(results):
            o_status = "✅ 성공" if r['oracle']['ok'] else f"❌ 실패 ({classify_error(r['oracle']['msg'])})"
            p_status = "✅ 성공" if r['postgresql']['ok'] else f"❌ 실패 ({classify_error(r['postgresql']['msg'])})"
            
            # 최종 판정
            if r['oracle']['ok'] and r['postgresql']['ok']:
                final_decision = "🟢 정상"
            elif r['oracle']['ok'] and not r['postgresql']['ok']:
                final_decision = "🔴 PG 수정 필요"
            elif not r['oracle']['ok'] and r['postgresql']['ok']:
                final_decision = "🟡 오라클 에러"
            else:
                final_decision = "⚫ 양측 에러"
                
            f.write(f"| {i+1} | {r['key']} | {o_status} | {p_status} | {final_decision} |\n")
            
        f.write("\n## 2. 상세 실패 원인\n\n")
        for i, r in enumerate(results):
            if r['oracle']['ok'] and r['postgresql']['ok']:
                continue
                
            f.write(f"### {i+1}. {r['key']}\n")
            f.write(f"- **기존 오류 내용**: `{r['prev_error']}`\n")
            
            if not r['oracle']['ok']:
                f.write(f"- **Oracle 검증 실패 원인** ({classify_error(r['oracle']['msg'])}):\n  ```\n  {r['oracle']['msg'].strip()}\n  ```\n")
                if r['oracle']['sql']:
                    f.write(f"  *검증 쿼리*: `{r['oracle']['sql']}`\n")
                    
            if not r['postgresql']['ok']:
                f.write(f"- **PostgreSQL 검증 실패 원인** ({classify_error(r['postgresql']['msg'])}):\n  ```\n  {r['postgresql']['msg'].strip()}\n  ```\n")
                if r['postgresql']['sql']:
                    f.write(f"  *검증 쿼리*: `{r['postgresql']['sql']}`\n")
            f.write("\n---\n\n")
    # 대화형 HTML 리포트 생성
    html_report_path = os.path.join(workspace_dir, "reverify_report.html")
    write_html_report(html_report_path, results)

    print("[+] 재검증 및 리포트 생성이 완료되었습니다.")

if __name__ == "__main__":
    main()
